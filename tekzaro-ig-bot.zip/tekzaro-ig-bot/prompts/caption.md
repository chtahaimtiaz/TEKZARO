# CAPTION PROMPT (replace with yours)

Write the Instagram caption.
- The first line must stand alone in the first 125 characters and carry the fact.
- Two or three short lines after it: what it means for readers in Pakistan.
- Credit the source as "Source: Tekzaro" and say the full story is at the link in bio.
- One call to action only: subscribe to the newsletter via the link in bio.
- At most five hashtags, no hashtag walls. No em dashes. No emoji, or at most one.
- Do not include any figure that is not in the article.
