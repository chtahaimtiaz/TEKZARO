# IMAGE PROMPT (replace with yours)

The pipeline uses the article's own featured image as the background of every
card. If an article has no image, or you later connect an image generator, this
prompt is used to write image_prompt.

Describe one clean, editorial, photographic background for the story: no text,
no logos, no real people's faces, no flags or party symbols, dark enough for white
headline text on top. One or two sentences.
