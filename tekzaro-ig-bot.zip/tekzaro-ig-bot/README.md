# Tekzaro Instagram reel bot

New article on tekzaro.co (RSS) -> Claude writes the reel script and caption from
your prompts -> faceless reel is rendered (cards over the article image, English
voice, Urdu voice, or text only) -> posted through Instagram's official API.
Runs on a VPS every 10 minutes.

Only articles published AFTER the first run are ever touched (`go_live`).

## What is in here

```
config.yaml          every setting (mode, style, voices, limits, sensitive words)
prompts/             YOUR prompts: reel_script.md, caption.md, image.md
bot/                 feed, generate, render, publish, notify, main
vendor/ig/           hook scorer, beat timer, caption linter, humanizer (MIT)
deploy/              systemd service + timer, Caddyfile
tests/               offline tests (python3 -m unittest discover -s tests)
```

## Safety design (read once)

- `mode: review` (default): every reel is sent to your Telegram with the caption.
  It posts only after you reply `approve 12`. Reply `reject 12` to drop it.
- `mode: auto`: posts by itself, BUT any story that trips a `sensitive_keywords`
  word, is flagged by the model as unsupported/allegation-based, or fails quality
  checks still waits for your approval. Set `skip_sensitive: true` to skip those
  stories entirely instead.
- Daily cap (`max_posts_per_day`), 3 retries per article, a failure alert on
  Telegram, and a lock so two runs never overlap.
- The prompt forbids facts that are not in the article. The quality gates
  (hook score, length, caption lint, humanizer) run on English output. Urdu
  output only gets length and structure checks.
- Keep `reel_style` to ONE style per story. Posting English, Urdu and text-only
  versions of the same story on one account looks like duplicate content. Use
  `style_by_category` to split by section, or a second account for Urdu.

## Setup, in order

### 1. Anthropic API key (separate from your claude.ai plan)
1. console.anthropic.com -> sign in -> add billing -> API keys -> Create key.
2. Put it in `.env` as `ANTHROPIC_API_KEY`.

### 2. Telegram bot (for previews, approvals, failure alerts)
1. In Telegram, message @BotFather -> `/newbot` -> copy the token to
   `TELEGRAM_BOT_TOKEN`.
2. Send any message to your new bot, then open
   `https://api.telegram.org/bot<TOKEN>/getUpdates` and copy `chat.id` into
   `TELEGRAM_CHAT_ID`. Only that chat can approve posts.

### 3. Meta developer app (Instagram API with Instagram Login)
Meta's screens change often, so treat this as the outline. We can go through it
together live.
1. developers.facebook.com -> My Apps -> Create app -> add the Instagram product
   and choose "API setup with Instagram login".
2. Your Instagram account must be a Professional account (it already is: Media/news
   company).
3. Add your account as an Instagram tester / role on the app and accept the invite
   in the Instagram app.
4. Generate a token for the account with `instagram_business_basic` and
   `instagram_business_content_publish`. Copy the token to `IG_ACCESS_TOKEN` and
   the Instagram user id to `IG_USER_ID`. Use the long-lived token (about 60 days).
   The bot refreshes it automatically every 30 days.
5. Try one manual publish first. If Meta answers with a permission error because
   the app is in development mode, submit the app for App Review for
   `instagram_business_content_publish` (you will need your privacy policy URL,
   tekzaro.co/privacy). Meta's public docs do not say whether your own account needs
   review, so find out by trying.

### 4. VPS (Ubuntu 22.04 or 24.04)
```bash
sudo apt update && sudo apt install -y ffmpeg python3-venv python3-pip fonts-noto-core libraqm0 caddy
sudo useradd -m -s /bin/bash tekzaro
sudo mkdir -p /opt/tekzaro-ig-bot && sudo chown tekzaro: /opt/tekzaro-ig-bot
# copy this folder to /opt/tekzaro-ig-bot (scp or git), then:
sudo -u tekzaro bash -c 'cd /opt/tekzaro-ig-bot && python3 -m venv .venv && .venv/bin/pip install -r requirements.txt && cp .env.example .env'
sudo -u tekzaro nano /opt/tekzaro-ig-bot/.env
```
Create a DNS record `reels.tekzaro.co` pointing at the VPS, put the Caddyfile from
`deploy/Caddyfile` in `/etc/caddy/Caddyfile`, run `sudo systemctl reload caddy`, and
set `public_base_url: https://reels.tekzaro.co` in `config.yaml`. Instagram downloads
each MP4 from that address, so it must be public HTTPS.

Then verify everything:
```bash
cd /opt/tekzaro-ig-bot && .venv/bin/python -m bot.main check
```
Open `out/check_ur.png`. Every Urdu letter must show with no empty boxes. If boxes
appear, install an Urdu font and point `fonts.urdu` at it.

### 5. Put your prompts in
Replace the text in `prompts/reel_script.md`, `prompts/caption.md` and
`prompts/image.md`. Keep the hard rules in the first file (facts only from the
article, no copying). The JSON output format is added by the code, so your prompts
do not need to describe it.

### 6. Rehearse, then go live
```bash
.venv/bin/python -m bot.main dry-run --limit 2          # real Claude + voice, renders, never posts
.venv/bin/python -m bot.main dry-run --limit 2 --style ur_voice
```
Watch the files in `out-dry/`. When you like them:
```bash
sudo cp deploy/tekzaro-bot.service deploy/tekzaro-bot.timer /etc/systemd/system/
sudo systemctl daemon-reload && sudo systemctl enable --now tekzaro-bot.timer
journalctl -u tekzaro-bot -f          # live log
.venv/bin/python -m bot.main status   # what the bot has seen and done
```
Run in `review` mode for the first week or two. Switch `mode: auto` when you trust it.

### 7. Housekeeping
Delete old renders weekly: `find /opt/tekzaro-ig-bot/out -mindepth 1 -maxdepth 1 -mtime +14 -exec rm -rf {} +`
(add it to cron). Back up `state/bot.db` if you care about history.

## Not covered yet
- Writing the website articles themselves. This bot starts from published articles.
- AI image generation. Today every card uses the article's own featured image. If an
  article has none, the card is a plain dark background. A generator can be plugged
  in later using `prompts/image.md`.
- Background music for voiced reels. Text-only reels use `assets/music.mp3` if you
  add a file you have the rights to.
- Text-to-speech uses the free `edge-tts` voices (en-GB-RyanNeural, ur-PK-AsadNeural).
  It is an unofficial service and could change; swap `_tts()` in `bot/render.py` for
  a paid provider if you need guarantees.
