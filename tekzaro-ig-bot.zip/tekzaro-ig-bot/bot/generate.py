"""Reel script + caption generation with the ig-skill quality gates.

Gates (hook score, beat timing, caption lint, humanizer) are English-heuristic
tools, so they run for English only. Urdu output is checked for structure and
length, and any problems send the reel to human review.
"""
import json
import logging
import os
import sys

from . import config

log = logging.getLogger("generate")

sys.path.insert(0, str(config.ROOT / "vendor" / "ig"))
import beats as ig_beats  # noqa: E402
import caption as ig_caption  # noqa: E402
import hookscore as ig_hook  # noqa: E402
import humanize as ig_human  # noqa: E402

CONTRACT = """
Return ONLY one JSON object, no prose, no code fences:
{
  "hook_options": ["three different spoken first lines"],
  "beats": ["spoken lines in order; the first is your best hook"],
  "cards": ["on-screen text for each beat, 6 words or fewer, same count as beats"],
  "caption": "the full Instagram caption",
  "image_prompt": "one or two sentences, or empty",
  "risk_flags": ["anything unsupported, allegation-based or sensitive; empty list if none"]
}
"""

LANG = {"en_voice": "English", "text_only": "English", "ur_voice": "Urdu (Urdu script)"}


def _prompt(cfg, article, style, feedback=None, previous=None):
    pdir = config.ROOT / "prompts"
    parts = [(pdir / n).read_text(encoding="utf-8") for n in
             ("reel_script.md", "caption.md", "image.md")]
    system = "\n\n".join(parts)
    system = (system.replace("<<language>>", LANG[style])
                    .replace("<<style>>", style)
                    .replace("<<target_seconds>>", str(cfg["target_reel_seconds"])))
    system += "\n\n" + CONTRACT
    user = (f"TITLE: {article['title']}\nSECTION: {article.get('category', '')}\n"
            f"PUBLISHED: {article.get('published', '')}\nLINK: {article['link']}\n\n"
            f"ARTICLE:\n{article.get('text') or article.get('description', '')}")
    if feedback:
        user += ("\n\nYour previous attempt had these problems. Fix all of them and "
                 f"return the full JSON again:\n- " + "\n- ".join(feedback)
                 + f"\n\nPrevious attempt:\n{json.dumps(previous, ensure_ascii=False)}")
    return system, user


def _parse_json(text):
    a, b = text.find("{"), text.rfind("}")
    if a < 0 or b < 0:
        raise ValueError("model returned no JSON")
    return json.loads(text[a:b + 1])


def _call_claude(cfg, system, user):
    import anthropic
    client = anthropic.Anthropic()
    msg = client.messages.create(
        model=cfg["claude_model"], max_tokens=3000, system=system,
        messages=[{"role": "user", "content": user}])
    return _parse_json("".join(b.text for b in msg.content if b.type == "text"))


def _structure_problems(out, cfg):
    p = []
    for k in ("hook_options", "beats", "cards", "caption"):
        if not out.get(k):
            p.append(f"missing {k}")
    if p:
        return p
    if len(out["beats"]) != len(out["cards"]):
        p.append("cards must be the same count as beats")
    if len(out["beats"]) < 4:
        p.append("need at least 4 spoken beats")
    if any(len(c.split()) > 7 for c in out["cards"]):
        p.append("every on-screen card must be 6 words or fewer")
    return p


def _gates_en(out, cfg):
    """Mutates `out` (cleans text, picks best hook). Returns list of problems."""
    problems = []
    lex = ig_human.load_lexicon()
    scored = [(ig_hook.run(h), h) for h in out["hook_options"]]
    (res, overall, verdict, flags), best = max(scored, key=lambda s: s[0][1])
    out["hook_score"] = round(overall, 1)
    out["beats"][0] = best
    if overall < 50:
        problems.append(f"best hook scores {overall:.0f}/100 ({verdict}); make it open on "
                        "a concrete fact from the article" + (f"; {flags[0]}" if flags else ""))
    # humanize spoken lines and caption (strips em dashes, slop words, invisible chars)
    out["beats"] = [ig_human.humanize(b, lex)[0].strip() for b in out["beats"]]
    out["caption"] = ig_human.humanize(out["caption"], lex)[0].strip()
    a = ig_beats.analyse("\n".join(out["beats"]), wpm=165, target=cfg["target_reel_seconds"])
    out["seconds_est"] = a["total_seconds"] if a else 0
    if a and a["total_seconds"] > cfg["max_reel_seconds"]:
        problems.append(f"script runs {a['total_seconds']:.0f}s, limit {cfg['max_reel_seconds']}s; cut lines")
    if a and a["beats"][0]["dur"] > 3.5:
        problems.append("hook line takes longer than 3.5 seconds to say; shorten it")
    c = ig_caption.analyse(out["caption"], keywords=cfg.get("search_terms"))
    for chk in c["checks"]:
        if chk["status"] == "FAIL":
            problems.append(f"caption {chk.get('check', '')}: {chk.get('detail', '')}".strip())
    return problems


def _gates_ur(out, cfg):
    wc = sum(len(b.split()) for b in out["beats"])
    out["seconds_est"] = round(wc / 2.4, 1)  # Urdu speech is a little slower
    out["hook_score"] = None
    if out["seconds_est"] > cfg["max_reel_seconds"]:
        return [f"script about {out['seconds_est']:.0f}s, limit {cfg['max_reel_seconds']}s; cut lines"]
    return []


def run_gates(out, cfg, style):
    problems = _structure_problems(out, cfg)
    if problems:
        return problems
    return _gates_ur(out, cfg) if style == "ur_voice" else _gates_en(out, cfg)


def generate(cfg, article, style, attempts=2):
    out, feedback, previous, problems = None, None, None, []
    for i in range(attempts):
        system, user = _prompt(cfg, article, style, feedback, previous)
        out = _call_claude(cfg, system, user)
        problems = run_gates(out, cfg, style)
        log.info("generation attempt %d, %d problems", i + 1, len(problems))
        if not problems:
            break
        feedback, previous = problems, out
    out["quality_problems"] = problems
    out.setdefault("risk_flags", [])
    return out


def stub(cfg, article, style):
    """Deterministic fake output so the render path can be tested with no API key."""
    title = article["title"]
    ur = style == "ur_voice"
    beats = ([title, "یہ خبر ٹیکزارو پر شائع ہوئی ہے", "تفصیل مضمون میں موجود ہے",
              "مزید خبروں کے لیے نیوز لیٹر دیکھیں"] if ur else
             [title, "Here is what the article reports.", "Read the full story on Tekzaro.",
              "Get the newsletter. Link in bio."])
    cards = ([title, "ٹیکزارو پر خبر", "مکمل تفصیل ویب سائٹ پر", "نیوز لیٹر"] if ur else
             [" ".join(title.split()[:6]), "What the article reports", "Full story on Tekzaro",
              "Newsletter in bio"])
    return {"hook_options": [title], "beats": beats, "cards": cards,
            "caption": f"{title}\nFull story at the link in bio. #pakistan #tech",
            "image_prompt": "", "risk_flags": [], "quality_problems": [],
            "seconds_est": 0, "hook_score": None, "stub": True}
