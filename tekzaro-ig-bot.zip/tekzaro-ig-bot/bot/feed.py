"""RSS polling and article page scraping (your own site)."""
import xml.etree.ElementTree as ET
from datetime import timezone
from email.utils import parsedate_to_datetime

import requests
from bs4 import BeautifulSoup

UA = {"User-Agent": "TekzaroReelBot/1.0 (+https://www.tekzaro.co)"}


def parse_feed(xml_bytes):
    root = ET.fromstring(xml_bytes)
    items = []
    for it in root.iter("item"):
        def g(tag):
            return (it.findtext(tag) or "").strip()
        pub = None
        if g("pubDate"):
            d = parsedate_to_datetime(g("pubDate"))
            if d.tzinfo is None:
                d = d.replace(tzinfo=timezone.utc)
            pub = d.astimezone(timezone.utc).isoformat()
        items.append({
            "guid": g("guid") or g("link"),
            "title": g("title"),
            "link": g("link"),
            "category": g("category"),
            "description": g("description"),
            "published": pub,
        })
    return items


def fetch_feed(url):
    r = requests.get(url, headers=UA, timeout=30)
    r.raise_for_status()
    return parse_feed(r.content)


def fetch_article(link):
    """Return {'text': ..., 'image_url': ...} from the article page."""
    r = requests.get(link, headers=UA, timeout=30)
    r.raise_for_status()
    soup = BeautifulSoup(r.text, "html.parser")
    og = soup.find("meta", attrs={"property": "og:image"})
    image_url = og["content"] if og and og.get("content") else None
    node = soup.find("article") or soup
    paras = [p.get_text(" ", strip=True) for p in node.find_all("p")]
    text = "\n".join(p for p in paras if len(p) > 40)[:6000]
    return {"text": text, "image_url": image_url}


def download(url, dest):
    r = requests.get(url, headers=UA, timeout=60)
    r.raise_for_status()
    with open(dest, "wb") as fh:
        fh.write(r.content)
    return dest
