"""Instagram API publishing (official Content Publishing API, Reels)."""
import logging
import time

import requests

from . import config

log = logging.getLogger("publish")


class PublishError(Exception):
    pass


def _check(r):
    try:
        j = r.json()
    except ValueError:
        raise PublishError(f"non-JSON response {r.status_code}: {r.text[:300]}")
    if r.status_code >= 400 or "error" in j:
        raise PublishError(str(j.get("error", j))[:500])
    return j


def token(db):
    """Prefer the refreshed token stored in the DB over the one in .env."""
    return db.get_meta("ig_token") or config.env("IG_ACCESS_TOKEN")


def refresh_token_if_due(cfg, db, every_days=30):
    last = float(db.get_meta("ig_token_refreshed", 0))
    if time.time() - last < every_days * 86400:
        return False
    host = cfg["instagram"]["api_host"]
    r = requests.get(f"{host}/refresh_access_token",
                     params={"grant_type": "ig_refresh_token", "access_token": token(db)},
                     timeout=30)
    j = _check(r)
    db.set_meta("ig_token", j["access_token"])
    db.set_meta("ig_token_refreshed", time.time())
    log.info("refreshed Instagram token, valid for %s seconds", j.get("expires_in"))
    return True


def publish_reel(cfg, db, video_url, caption, poll_every=30, max_polls=10):
    host = cfg["instagram"]["api_host"]
    uid, tok = config.env("IG_USER_ID"), token(db)
    if not uid or not tok:
        raise PublishError("IG_USER_ID / IG_ACCESS_TOKEN not set")
    j = _check(requests.post(f"{host}/{uid}/media", data={
        "media_type": "REELS", "video_url": video_url, "caption": caption,
        "share_to_feed": "true", "access_token": tok}, timeout=60))
    container = j["id"]
    log.info("container %s created, waiting for processing", container)
    for _ in range(max_polls):
        time.sleep(poll_every)
        s = _check(requests.get(f"{host}/{container}", params={
            "fields": "status_code,status", "access_token": tok}, timeout=30))
        code = s.get("status_code")
        if code == "FINISHED":
            break
        if code in ("ERROR", "EXPIRED"):
            raise PublishError(f"container {code}: {s.get('status')}")
    else:
        raise PublishError("container not FINISHED in time; will retry next run")
    pub = _check(requests.post(f"{host}/{uid}/media_publish", data={
        "creation_id": container, "access_token": tok}, timeout=60))
    media_id = pub["id"]
    permalink = None
    try:
        permalink = _check(requests.get(f"{host}/{media_id}", params={
            "fields": "permalink", "access_token": tok}, timeout=30)).get("permalink")
    except PublishError:
        pass
    return media_id, permalink
