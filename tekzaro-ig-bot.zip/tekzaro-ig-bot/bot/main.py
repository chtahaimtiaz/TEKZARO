"""Orchestrator.  Run `python -m bot.main run` every few minutes (systemd timer)."""
import argparse
import fcntl
import json
import logging
import os
import re
import shutil
import sys
from datetime import datetime, timezone

from . import config, feed, generate, notify, publish, render
from .storage import DB

log = logging.getLogger("main")


def _style_for(cfg, row, override=None):
    return (override or cfg.get("style_by_category", {}).get(row["category"])
            or cfg["reel_style"])


def _sensitive_hits(cfg, row, article):
    hay = (row["title"] + " " + (article.get("text") or "")[:1500]).lower()
    return [k for k in cfg.get("sensitive_keywords", []) if re.search(r"\b" + re.escape(k.lower()) + r"\b", hay)]


def _fail(cfg, db, row, err):
    attempts = row["attempts"] + 1
    status = "failed" if attempts >= cfg["max_attempts"] else row["status"]
    db.update(row["id"], attempts=attempts, error=str(err)[:500], status=status)
    log.error("article %s: %s", row["id"], err)
    if status == "failed":
        notify.send(f"FAILED after {attempts} tries: {row['title']}\n{err}")


def process(cfg, db, aid, dry=False, stub=False, no_fetch=False, style=None, item=None):
    row = db.get(aid)
    data = db.data(aid)
    style = style or _style_for(cfg, row)
    try:
        if "article" not in data:
            if no_fetch:
                data["article"] = {"text": (item or {}).get("description", ""), "image_url": None}
            else:
                data["article"] = feed.fetch_article(row["link"])
        art = {**data["article"], "title": row["title"], "link": row["link"],
               "category": row["category"], "published": row["published"],
               "description": (item or {}).get("description", "")}
        hits = _sensitive_hits(cfg, row, art)
        if hits and cfg.get("skip_sensitive"):
            db.update(aid, status="skipped", data=data, error="sensitive: " + ", ".join(hits))
            return
        if "gen" not in data:
            data["gen"] = generate.stub(cfg, art, style) if stub else generate.generate(cfg, art, style)
            data["gen"]["risk_flags"] = list(data["gen"].get("risk_flags", [])) + \
                [f"sensitive keyword: {h}" for h in hits]
            data["style"] = style
            db.update(aid, data=data)
        gen = data["gen"]
        if "video" not in data:
            out_dir = config.path(cfg, cfg["paths"]["out"], f"{aid:05d}")
            bg = None
            img_url = data["article"].get("image_url")
            if img_url and not no_fetch:
                try:
                    os.makedirs(out_dir, exist_ok=True)
                    bg = feed.download(img_url, str(out_dir / "bg.jpg"))
                except Exception as e:  # image is optional
                    log.warning("no background image: %s", e)
            video, secs = render.render_reel(cfg, str(out_dir), gen, bg, style)
            data["video"] = os.path.relpath(video, config.path(cfg, cfg["paths"]["out"]))
            data["seconds"] = round(secs, 1)
            db.update(aid, data=data)
        if dry:
            db.update(aid, status="rendered", data=data)
            return
        reasons = list(gen.get("risk_flags", [])) + list(gen.get("quality_problems", []))
        if cfg["mode"] == "review" or reasons:
            db.update(aid, status="pending_review", data=data)
            why = "review mode" if cfg["mode"] == "review" and not reasons else "; ".join(reasons)
            notify.send_preview(
                config.path(cfg, cfg["paths"]["out"], data["video"]),
                f"[{aid}] {row['title']}\nWhy review: {why}\n\n{gen['caption']}\n\n"
                f"Reply: approve {aid}   or   reject {aid}")
        else:
            db.update(aid, status="approved", data=data)
            publish_row(cfg, db, aid)
    except Exception as e:  # noqa: BLE001 - one bad article must not stop the run
        _fail(cfg, db, db.get(aid), e)


def publish_row(cfg, db, aid):
    row = db.get(aid)
    if db.published_last_24h() >= cfg["max_posts_per_day"]:
        log.info("daily cap reached, %s waits", aid)
        return
    data = db.data(aid)
    url = cfg["public_base_url"].rstrip("/") + "/" + data["video"]
    try:
        media_id, permalink = publish.publish_reel(cfg, db, url, data["gen"]["caption"])
        db.update(aid, status="published", ig_media_id=media_id, error=None)
        notify.send(f"Published: {row['title']}\n{permalink or media_id}")
    except Exception as e:  # noqa: BLE001
        _fail(cfg, db, row, e)


def _parse_iso(s):
    return datetime.fromisoformat(s).astimezone(timezone.utc)


def run_once(cfg):
    lock = open(config.path(cfg, "state", "run.lock"), "w")
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        log.info("another run is active, exiting")
        return
    db = DB(config.path(cfg, cfg["paths"]["db"]))

    go_live = cfg.get("go_live") or db.get_meta("go_live")
    if not go_live:
        go_live = datetime.now(timezone.utc).isoformat()
        log.info("first run: go_live set to %s, only newer articles will be posted", go_live)
    db.set_meta("go_live", go_live)
    cutoff = _parse_iso(go_live)

    try:
        publish.refresh_token_if_due(cfg, db)
    except Exception as e:  # noqa: BLE001
        notify.send(f"Instagram token refresh failed: {e}")

    for cmd, aid in notify.poll_commands(db):
        row = db.get(aid)
        if not row or row["status"] != "pending_review":
            continue
        db.update(aid, status="approved" if cmd == "approve" else "rejected")
        notify.send(f"{cmd}d [{aid}] {row['title']}")

    try:
        items = feed.fetch_feed(cfg["feed_url"])
    except Exception as e:  # noqa: BLE001
        notify.send(f"Feed fetch failed: {e}")
        items = []
    for it in items:
        if it["published"] and _parse_iso(it["published"]) > cutoff:
            if db.add_article(it):
                log.info("new article: %s", it["title"])

    for row in db.by_status("new")[:5]:
        process(cfg, db, row["id"])
    for row in db.by_status("approved"):
        publish_row(cfg, db, row["id"])


def dry_run(cfg, args):
    cfg = {**cfg, "paths": {"db": "state/dry.db", "out": "out-dry"}}
    for p in (config.path(cfg, "state", "dry.db"), config.path(cfg, "out-dry")):
        if p.is_dir():
            shutil.rmtree(p)
        elif p.exists():
            p.unlink()
    os.makedirs(config.path(cfg, "out-dry"), exist_ok=True)
    db = DB(config.path(cfg, cfg["paths"]["db"]))
    if args.feed_file:
        items = feed.parse_feed(open(args.feed_file, "rb").read())
    else:
        items = feed.fetch_feed(cfg["feed_url"])
    items = sorted([i for i in items if i["published"]], key=lambda i: i["published"], reverse=True)[:args.limit]
    for it in items:
        aid = db.add_article(it)
        process(cfg, db, aid, dry=True, stub=args.stub, no_fetch=args.no_fetch, style=args.style, item=it)
        row, data = db.get(aid), db.data(aid)
        gen = data.get("gen", {})
        print(f"\n[{aid}] {row['title']}\n  status: {row['status']}  style: {data.get('style')}"
              f"  seconds: {data.get('seconds')}  hook score: {gen.get('hook_score')}"
              f"\n  video: {config.path(cfg, 'out-dry', data.get('video', '-'))}"
              f"\n  problems: {gen.get('quality_problems')}  risk: {gen.get('risk_flags')}"
              f"\n  error: {row['error']}")


def check(cfg):
    """Setup check for a new VPS. Prints OK/MISSING lines and writes out/check_*.png."""
    ok = True

    def line(good, text):
        nonlocal ok
        ok = ok and good
        print(("OK       " if good else "MISSING  ") + text)

    for tool in ("ffmpeg", "ffprobe"):
        line(shutil.which(tool) is not None, f"{tool} on PATH")
    for name in ("ANTHROPIC_API_KEY", "IG_USER_ID", "IG_ACCESS_TOKEN"):
        line(bool(config.env(name)), f"{name} set")
    line(notify.enabled(), "Telegram bot token and chat id set (needed for review mode)")
    for key in ("latin", "urdu"):
        line(os.path.exists(cfg["fonts"][key]), f"{key} font file {cfg['fonts'][key]}")
    line("example.com" not in cfg["public_base_url"], f"public_base_url = {cfg['public_base_url']}")
    try:
        os.makedirs(config.path(cfg, cfg["paths"]["out"]), exist_ok=True)
        render.make_card("Pakistan tech news, verified", None,
                         str(config.path(cfg, cfg["paths"]["out"], "check_en.png")), cfg)
        render.make_card("ایف بی آر غلط معلومات دینے والوں پر جرمانہ کرے گا", None,
                         str(config.path(cfg, cfg["paths"]["out"], "check_ur.png")), cfg, rtl=True)
        print("OK       wrote out/check_en.png and out/check_ur.png. Open the Urdu one: every "
              "letter must show, with no empty boxes. If boxes appear, install an Urdu font and "
              "set fonts.urdu in config.yaml.")
    except Exception as e:  # noqa: BLE001
        line(False, f"card render failed: {e}")
    print("\nAll required items present." if ok else "\nFix the MISSING items above.")


def main(argv=None):
    ap = argparse.ArgumentParser(prog="bot")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("check", help="verify tools, keys, fonts and write sample cards")
    sub.add_parser("run", help="one cycle: poll, generate, render, review or publish")
    sub.add_parser("status")
    for name in ("approve", "reject"):
        p = sub.add_parser(name)
        p.add_argument("id", type=int)
    d = sub.add_parser("dry-run", help="render the newest articles, never posts or messages")
    d.add_argument("--limit", type=int, default=2)
    d.add_argument("--stub", action="store_true", help="skip Claude, use canned text")
    d.add_argument("--no-fetch", action="store_true", help="do not fetch article pages/images")
    d.add_argument("--feed-file")
    d.add_argument("--style", choices=["en_voice", "ur_voice", "text_only"])
    ap.add_argument("--config")
    args = ap.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
    cfg = config.load(args.config)
    os.makedirs(config.path(cfg, "state"), exist_ok=True)

    if args.cmd == "check":
        check(cfg)
    elif args.cmd == "run":
        run_once(cfg)
    elif args.cmd == "dry-run":
        dry_run(cfg, args)
    elif args.cmd == "status":
        db = DB(config.path(cfg, cfg["paths"]["db"]))
        print("go_live:", db.get_meta("go_live"))
        for r in db.conn.execute("SELECT id,status,attempts,title FROM articles ORDER BY id DESC LIMIT 20"):
            print(f"[{r['id']}] {r['status']:<15} tries={r['attempts']}  {r['title']}")
    else:
        db = DB(config.path(cfg, cfg["paths"]["db"]))
        row = db.get(args.id)
        if not row:
            sys.exit("no such id")
        if args.cmd == "approve":
            db.update(args.id, status="approved")
            publish_row(cfg, db, args.id)
        else:
            db.update(args.id, status="rejected")


if __name__ == "__main__":
    main()
