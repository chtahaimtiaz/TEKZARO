"""Faceless reel renderer: text cards over the article image, optional TTS, ffmpeg."""
import asyncio
import logging
import os
import subprocess

from PIL import Image, ImageDraw, ImageEnhance, ImageFont, ImageOps

log = logging.getLogger("render")

W, H = 1080, 1920
# Instagram UI covers the top, bottom and right edge. Keep text inside this box.
SAFE_X0, SAFE_X1, SAFE_Y0, SAFE_Y1 = 60, 850, 230, 1440


def _font(path, size):
    return ImageFont.truetype(path, size, layout_engine=ImageFont.Layout.RAQM)


def _wrap(text, font, max_w, rtl):
    words, lines, cur = text.split(), [], ""
    kw = {"direction": "rtl", "language": "ur"} if rtl else {}
    for w in words:
        trial = (cur + " " + w).strip()
        if font.getlength(trial, **kw) <= max_w or not cur:
            cur = trial
        else:
            lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines


def make_card(text, bg_path, out_path, cfg, rtl=False, cta=False):
    brand = cfg["brand"]
    if bg_path and os.path.exists(bg_path):
        bg = ImageOps.fit(Image.open(bg_path).convert("RGB"), (W, H))
        bg = ImageEnhance.Brightness(bg).enhance(0.40)
    else:
        bg = Image.new("RGB", (W, H), "#0b0f14")
    img = bg.copy()
    d = ImageDraw.Draw(img)
    fpath = cfg["fonts"]["urdu"] if rtl else cfg["fonts"]["latin"]
    kw = {"direction": "rtl", "language": "ur"} if rtl else {}

    d.text((SAFE_X0, SAFE_Y0 + 10), brand["name"], font=_font(cfg["fonts"]["latin"], 44),
           fill=brand["accent"])
    d.rectangle([SAFE_X0, SAFE_Y0 + 70, SAFE_X0 + 120, SAFE_Y0 + 76], fill=brand["accent"])

    box_w, box_h = SAFE_X1 - SAFE_X0, 820
    size = 110
    while size > 44:
        font = _font(fpath, size)
        lines = _wrap(text, font, box_w, rtl)
        lh = int(size * (1.5 if rtl else 1.25))
        if len(lines) * lh <= box_h:
            break
        size -= 6
    block_h = len(lines) * lh
    y = SAFE_Y0 + 140 + (box_h - block_h) // 2
    cx = (SAFE_X0 + SAFE_X1) // 2
    for line in lines:
        d.text((cx, y), line, font=font, fill="white", anchor="ma", **kw)
        y += lh
    img.save(out_path)
    return out_path


def _run(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError(f"{cmd[0]} failed: {r.stderr[-800:]}")
    return r.stdout


def _duration(path):
    out = _run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                "-of", "default=nk=1:nw=1", str(path)])
    return float(out.strip())


def _tts(text, voice, rate, dest):
    import edge_tts

    async def go():
        await edge_tts.Communicate(text, voice, rate=rate).save(str(dest))
    asyncio.run(go())
    return dest


def _segment(card, audio, dur, dest):
    cmd = ["ffmpeg", "-y", "-loop", "1", "-framerate", "30", "-i", str(card)]
    if audio:
        cmd += ["-i", str(audio), "-af", "apad"]
    else:
        cmd += ["-f", "lavfi", "-i", "anullsrc=r=44100:cl=stereo"]
    cmd += ["-t", f"{dur:.2f}", "-vf", "format=yuv420p", "-c:v", "libx264", "-preset", "veryfast",
            "-crf", "21", "-r", "30", "-c:a", "aac", "-ar", "44100", "-ac", "2", "-b:a", "128k",
            str(dest)]
    _run(cmd)


def render_reel(cfg, workdir, gen, bg_path, style):
    """Return path to final MP4 in `workdir`."""
    os.makedirs(workdir, exist_ok=True)
    rtl = style == "ur_voice"
    voiced = style in ("en_voice", "ur_voice") and cfg["tts"]["provider"] != "none"
    voice = cfg["tts"]["voice_ur"] if rtl else cfg["tts"]["voice_en"]
    segs = []
    for i, (beat, card_text) in enumerate(zip(gen["beats"], gen["cards"])):
        card = os.path.join(workdir, f"card{i}.png")
        make_card(card_text, bg_path, card, cfg, rtl=rtl)
        audio = None
        if voiced:
            audio = os.path.join(workdir, f"beat{i}.mp3")
            _tts(beat, voice, cfg["tts"]["rate"], audio)
            dur = _duration(audio) + 0.25
        else:
            words = len((card_text if style == "text_only" else beat).split())
            dur = max(2.0, words / 2.8 + 0.8)
        seg = os.path.join(workdir, f"seg{i}.mp4")
        _segment(card, audio, dur, seg)
        segs.append(seg)
    # outro card
    cta_text = cfg["brand"]["cta_ur"] if rtl else cfg["brand"]["cta_en"]
    card = os.path.join(workdir, "cardX.png")
    make_card(cta_text, bg_path, card, cfg, rtl=rtl, cta=True)
    seg = os.path.join(workdir, "segX.mp4")
    _segment(card, None, 2.0, seg)
    segs.append(seg)

    lst = os.path.join(workdir, "list.txt")
    with open(lst, "w") as fh:
        fh.write("".join(f"file '{os.path.abspath(s)}'\n" for s in segs))
    joined = os.path.join(workdir, "joined.mp4")
    _run(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", lst, "-c", "copy", joined])

    final = os.path.join(workdir, "reel.mp4")
    music = os.path.join(cfg["_root"], cfg["assets"]["music"])
    if style == "text_only" and os.path.exists(music):
        _run(["ffmpeg", "-y", "-i", joined, "-stream_loop", "-1", "-i", music,
              "-filter_complex", "[1:a]volume=0.18[m]", "-map", "0:v", "-map", "[m]",
              "-shortest", "-c:v", "copy", "-c:a", "aac", "-movflags", "+faststart", final])
    else:
        _run(["ffmpeg", "-y", "-i", joined, "-c", "copy", "-movflags", "+faststart", final])
    total = _duration(final)
    if total > 90:
        raise RuntimeError(f"reel is {total:.0f}s, over the 90s Reels limit")
    log.info("rendered %s (%.1fs)", final, total)
    return final, total
