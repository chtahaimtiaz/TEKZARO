"""Config and .env loading."""
import os
import pathlib

import yaml

ROOT = pathlib.Path(__file__).resolve().parent.parent


def _load_dotenv(path):
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


def load(path=None):
    _load_dotenv(ROOT / ".env")
    p = pathlib.Path(path or os.environ.get("BOT_CONFIG", ROOT / "config.yaml"))
    cfg = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    cfg["_root"] = str(ROOT)
    return cfg


def path(cfg, *parts):
    return pathlib.Path(cfg["_root"], *parts)


def env(name, default=None):
    return os.environ.get(name, default)
