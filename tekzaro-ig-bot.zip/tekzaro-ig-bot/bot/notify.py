"""Telegram alerts and one-message approvals."""
import logging
import re

import requests

from . import config

log = logging.getLogger("notify")


def _api(method):
    return f"https://api.telegram.org/bot{config.env('TELEGRAM_BOT_TOKEN')}/{method}"


def enabled():
    return bool(config.env("TELEGRAM_BOT_TOKEN") and config.env("TELEGRAM_CHAT_ID"))


def send(text):
    if not enabled():
        log.info("[telegram off] %s", text)
        return
    try:
        requests.post(_api("sendMessage"), data={
            "chat_id": config.env("TELEGRAM_CHAT_ID"), "text": text[:4000]}, timeout=30)
    except requests.RequestException as e:
        log.warning("telegram send failed: %s", e)


def send_preview(video_path, text):
    if not enabled():
        log.info("[telegram off] preview %s\n%s", video_path, text)
        return
    try:
        with open(video_path, "rb") as fh:
            requests.post(_api("sendVideo"), data={
                "chat_id": config.env("TELEGRAM_CHAT_ID"), "caption": text[:1000]},
                files={"video": fh}, timeout=180)
    except requests.RequestException as e:
        log.warning("telegram preview failed: %s", e)


def poll_commands(db):
    """Return [('approve'|'reject', id)] from the owner's chat only."""
    if not enabled():
        return []
    offset = int(db.get_meta("tg_offset", 0))
    try:
        r = requests.get(_api("getUpdates"), params={"offset": offset, "timeout": 0}, timeout=30)
        updates = r.json().get("result", [])
    except (requests.RequestException, ValueError):
        return []
    cmds = []
    for u in updates:
        offset = max(offset, u["update_id"] + 1)
        m = u.get("message") or {}
        if str(m.get("chat", {}).get("id")) != str(config.env("TELEGRAM_CHAT_ID")):
            continue
        hit = re.match(r"^\s*/?(approve|reject)\s+(\d+)\s*$", m.get("text", ""), re.I)
        if hit:
            cmds.append((hit.group(1).lower(), int(hit.group(2))))
    db.set_meta("tg_offset", offset)
    return cmds
