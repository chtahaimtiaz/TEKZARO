"""SQLite state: one row per article, plus a small key/value table."""
import json
import sqlite3
import time

SCHEMA = """
CREATE TABLE IF NOT EXISTS meta(k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE IF NOT EXISTS articles(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guid TEXT UNIQUE,
  link TEXT, title TEXT, category TEXT, published TEXT,
  status TEXT DEFAULT 'new',
  attempts INTEGER DEFAULT 0,
  data TEXT DEFAULT '{}',
  error TEXT,
  ig_media_id TEXT,
  created REAL, updated REAL
);
"""

# new -> rendered -> pending_review -> published
#     \-> skipped | failed | rejected


class DB:
    def __init__(self, path):
        self.conn = sqlite3.connect(str(path))
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(SCHEMA)
        self.conn.commit()

    def get_meta(self, k, default=None):
        r = self.conn.execute("SELECT v FROM meta WHERE k=?", (k,)).fetchone()
        return r["v"] if r else default

    def set_meta(self, k, v):
        self.conn.execute("INSERT OR REPLACE INTO meta(k,v) VALUES(?,?)", (k, str(v)))
        self.conn.commit()

    def add_article(self, item):
        now = time.time()
        try:
            cur = self.conn.execute(
                "INSERT INTO articles(guid,link,title,category,published,created,updated)"
                " VALUES(?,?,?,?,?,?,?)",
                (item["guid"], item["link"], item["title"], item.get("category", ""),
                 item.get("published"), now, now))
            self.conn.commit()
            return cur.lastrowid
        except sqlite3.IntegrityError:
            return None

    def get(self, aid):
        r = self.conn.execute("SELECT * FROM articles WHERE id=?", (aid,)).fetchone()
        return dict(r) if r else None

    def data(self, aid):
        r = self.get(aid)
        return json.loads(r["data"]) if r else {}

    def update(self, aid, **fields):
        if "data" in fields and not isinstance(fields["data"], str):
            fields["data"] = json.dumps(fields["data"], ensure_ascii=False)
        fields["updated"] = time.time()
        cols = ", ".join(f"{k}=?" for k in fields)
        self.conn.execute(f"UPDATE articles SET {cols} WHERE id=?", (*fields.values(), aid))
        self.conn.commit()

    def by_status(self, *statuses):
        q = ",".join("?" for _ in statuses)
        rows = self.conn.execute(
            f"SELECT * FROM articles WHERE status IN ({q}) ORDER BY published, id", statuses)
        return [dict(r) for r in rows]

    def published_last_24h(self):
        r = self.conn.execute(
            "SELECT COUNT(*) c FROM articles WHERE status='published' AND updated>?",
            (time.time() - 86400,)).fetchone()
        return r["c"]
