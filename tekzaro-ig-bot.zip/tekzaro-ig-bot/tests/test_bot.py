"""Offline tests: no network, no API keys. Run: python3 -m unittest discover -s tests"""
import os
import pathlib
import shutil
import sys
import tempfile
import unittest
from datetime import datetime, timezone

ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from bot import feed, generate, main as bot_main, render  # noqa: E402
from bot.storage import DB  # noqa: E402

FIXTURE = ROOT / "tests" / "fixture_feed.xml"


class FeedTests(unittest.TestCase):
    def test_parse(self):
        items = feed.parse_feed(FIXTURE.read_bytes())
        self.assertEqual(len(items), 3)
        self.assertEqual(items[0]["guid"], "fixture-fbr")
        self.assertTrue(items[0]["published"].startswith("2026-10-12T08:07:04"))
        self.assertEqual(items[0]["category"], "Pakistan Tech")

    def test_cutoff_and_dedup(self):
        items = feed.parse_feed(FIXTURE.read_bytes())
        cutoff = datetime(2026, 10, 12, 8, 10, tzinfo=timezone.utc)
        newer = [i for i in items if bot_main._parse_iso(i["published"]) > cutoff]
        self.assertEqual([i["guid"] for i in newer], ["fixture-police"])  # old posts never touched
        tmp = tempfile.mkdtemp()
        db = DB(os.path.join(tmp, "t.db"))
        self.assertIsNotNone(db.add_article(items[0]))
        self.assertIsNone(db.add_article(items[0]))  # same guid is never queued twice
        shutil.rmtree(tmp)


class GenerateTests(unittest.TestCase):
    cfg = {"target_reel_seconds": 30, "max_reel_seconds": 45, "search_terms": ["pakistan tech news"]}

    def test_structure_rejects_mismatch(self):
        out = {"hook_options": ["a"], "beats": ["a", "b", "c", "d"], "cards": ["x"], "caption": "c"}
        self.assertTrue(generate._structure_problems(out, self.cfg))

    def test_json_parse_with_noise(self):
        self.assertEqual(generate._parse_json('here {"a": 1} done'), {"a": 1})

    def test_english_gates_clean_text(self):
        out = {
            "hook_options": ["FBR will fine anyone who files false information in a tax return.",
                             "Hey guys, today I want to talk about taxes"],
            "beats": ["x", "The penalty applies to filers who give wrong details.",
                      "It is a game-changer — and the rules start soon.",
                      "Get the newsletter. Link in bio."],
            "cards": ["FBR fines false returns", "Wrong details cost you", "Rules start soon", "Newsletter"],
            "caption": "FBR will fine false tax return information.\nFull story at the link in bio. #pakistan",
        }
        problems = generate._gates_en(out, self.cfg)
        self.assertEqual(out["beats"][0], out["hook_options"][0])  # best hook wins
        self.assertNotIn("—", " ".join(out["beats"]))  # em dash stripped
        self.assertIsInstance(problems, list)


class RenderTests(unittest.TestCase):
    def setUp(self):
        self.cfg = bot_main.config.load(str(ROOT / "tests" / "config.test.yaml"))

    def test_cards_en_and_ur(self):
        tmp = tempfile.mkdtemp()
        render.make_card("FBR to penalise false information in tax returns", None,
                         os.path.join(tmp, "en.png"), self.cfg)
        render.make_card("ایف بی آر غلط معلومات پر جرمانہ کرے گا", None,
                         os.path.join(tmp, "ur.png"), self.cfg, rtl=True)
        from PIL import Image
        for n in ("en.png", "ur.png"):
            self.assertEqual(Image.open(os.path.join(tmp, n)).size, (1080, 1920))
        shutil.rmtree(tmp)


class FlowTests(unittest.TestCase):
    """Whole run_once cycle with network, Claude, Telegram and Instagram mocked."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        cfg = bot_main.config.load(str(ROOT / "tests" / "config.test.yaml"))
        cfg["paths"] = {"db": os.path.join(self.tmp, "t.db"), "out": os.path.join(self.tmp, "out")}
        cfg["go_live"] = "2026-10-12T08:00:00+00:00"
        self.cfg = cfg
        os.makedirs(os.path.join(ROOT, "state"), exist_ok=True)
        self.sent, self.published, self.cmds = [], [], []
        m = bot_main
        self._orig = (m.feed.fetch_feed, m.feed.fetch_article, m.generate.generate,
                      m.publish.publish_reel, m.publish.refresh_token_if_due,
                      m.notify.poll_commands, m.notify.send, m.notify.send_preview)
        m.feed.fetch_feed = lambda url: feed.parse_feed(FIXTURE.read_bytes())
        m.feed.fetch_article = lambda link: {"text": "Plain article text.", "image_url": None}
        m.generate.generate = lambda c, a, s: generate.stub(c, a, s)
        m.publish.publish_reel = lambda c, db, url, cap: (self.published.append(url) or ("1", "https://ig/x"))
        m.publish.refresh_token_if_due = lambda *a, **k: False
        m.notify.poll_commands = lambda db: self.cmds
        m.notify.send = lambda t: self.sent.append(t)
        m.notify.send_preview = lambda p, t: self.sent.append("PREVIEW " + t)

    def tearDown(self):
        m = bot_main
        (m.feed.fetch_feed, m.feed.fetch_article, m.generate.generate, m.publish.publish_reel,
         m.publish.refresh_token_if_due, m.notify.poll_commands, m.notify.send,
         m.notify.send_preview) = self._orig
        shutil.rmtree(self.tmp)

    def statuses(self):
        db = DB(self.cfg["paths"]["db"])
        return {r["title"][:12]: r["status"] for r in db.by_status(
            "new", "pending_review", "approved", "published", "failed", "skipped", "rejected")}

    def test_review_mode_then_approve(self):
        self.cfg["mode"] = "review"
        bot_main.run_once(self.cfg)
        st = self.statuses()
        self.assertEqual(set(st.values()), {"pending_review"})
        self.assertEqual(len(st), 2)  # the 29 Sep article is older than go-live and ignored
        self.assertEqual(self.published, [])
        self.cmds = [("approve", 1)]
        bot_main.run_once(self.cfg)
        self.assertEqual(len(self.published), 1)
        self.assertIn("published", self.statuses().values())

    def test_auto_mode_holds_sensitive(self):
        self.cfg["mode"] = "auto"
        bot_main.run_once(self.cfg)
        st = self.statuses()
        self.assertEqual(st["FBR to Penal"], "published")           # clean story posts itself
        self.assertEqual(st["Islamabad Po"], "pending_review")       # 'rape' keyword waits for a human
        self.assertEqual(len(self.published), 1)

    def test_no_double_post_on_second_run(self):
        self.cfg["mode"] = "auto"
        bot_main.run_once(self.cfg)
        bot_main.run_once(self.cfg)
        self.assertEqual(len(self.published), 1)


if __name__ == "__main__":
    unittest.main()
